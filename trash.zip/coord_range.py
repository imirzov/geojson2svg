#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Calculates coordinate range (dX and dY) of a geojson file.
TODO Not file, but Polygon, MultiPolygon, MapObj.
"""

from typing import Any, cast

# import base.file
# import settings


def get_coordinates(d: Any) -> list[list[float]]:
    """Returns nested lists with features XY coordinates."""
    coordinates: list[list[float]] = []
    if isinstance(d, dict):
        if 'coordinates' in d:
            coordinates.extend(cast(list[list[float]], d['coordinates']))
        else:
            for v in cast(dict[str, Any], d).values():
                coordinates.extend(get_coordinates(v))
    if isinstance(d, list):
        for item in cast(list[Any], d):
            coordinates.extend(get_coordinates(item))
    return coordinates


def flatten_list(list_: list[Any]) -> list[tuple[float, float]]:
    """Makes nested list of coords flatten."""
    res: list[tuple[float, float]] = []
    if list_:
        L = list_[0]
        if isinstance(L, float):
            assert len(list_) == 2, f'Expected 2 elements, got {len(list_)}'
            res.append(tuple(list_))
        elif isinstance(L, list):
            for item in list_:
                res.extend(flatten_list(item))
        else:
            raise Exception(f'Unexpected list element:\n{L}')
    return res


def get_coord_range(coords: list[tuple[float, float]], index: int) -> float:
    min_coord = coords[0][index]
    max_coord = coords[0][index]
    for xy_couple in coords[1:]:
        min_coord = min(min_coord, xy_couple[index])
        max_coord = max(max_coord, xy_couple[index])
    return max_coord - min_coord


def main() -> None:
    # fpath = settings.files / '1.regions.geojson'
    # assert fpath.exists(), f'File not found:\n{fpath}'
    # d = base.file.get_any_json_code(fpath)
    # list_ = get_coordinates(d)
    # coords = flatten_list(list_)
    # assert len(coords) > 0, f'No coordinates in file:\n{fpath}'
    # print(get_coord_range(coords, 0))  # X coords
    # print(get_coord_range(coords, 1))  # Y coords

    from tools.geojson.geojson2svg.lands import Regions
    from tools.geojson.geojson2svg.common import MapObj, get_bbox
    mo = MapObj(Regions)
    xmin, xmax, ymin, ymax = get_bbox(mo)
    print(xmax - xmin, ymax - ymin)
